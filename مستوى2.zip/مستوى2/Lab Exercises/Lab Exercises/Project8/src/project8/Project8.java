
package project8;


public class Project8 {

  
    public static void main(String[] args) {
        
        System.out.println("Numbers from 1 to 10");
        for(int x=1; x<=10; x++)
            System.out.println(x);
        
        System.out.println("Numbers from 10 to 1");
        for(int y=10; y>=1; y--)
            System.out.println(y);
        
        System.out.println("Odd numbers from 1to 10");
        for(int z=1; z<=10; z=z+2)
            System.out.println(z);
        
        System.out.println("Even numbers from 1 to 10");
        for(int m=2; m<=10; m=m+2)
            System.out.println(m);
        
        System.out.println(Math.sqrt (25.0));

    }
    
}
