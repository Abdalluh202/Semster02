
package project10;


public class Project10 {

 
    public static void main(String[] args) {
        
        System.out.println("Numbers from 1 to 10");
        int x=1; 
        while(x<=10)
        {
            System.out.println(x);
            x= x+1;
        }
      
       int y=10;
        System.out.println("Numbers from 10 to 1");
        while (y>=1)
        {
            System.out.println(y);
            y=y-1;
        }
        
        System.out.println("Odd numbers from 1to 10");
         int z=1; 
        while(z<=10)
        {
            System.out.println(z);
            z= z+2;
        }
        
        System.out.println("Even numbers from 1 to 10");
         int m=2; 
        while(m<=10)
        {
            System.out.println(m);
            m=m+2;
        }
    }
    
}
