package teacher_aml;

import java.util.*;

public class testQ {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        Scanner in = new Scanner(System.in);

        for (int p = 1; p < 10; p = p + 2) {
            System.out.println(p);
        }
        System.out.println("المجموع");
        int sum = 0, S;
        for (S = 1; S <= 10; S = S + 2) {
            sum = sum + S;

        }
        System.out.println(sum);

    }

}
